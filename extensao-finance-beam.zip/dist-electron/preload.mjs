"use strict";
const electron = require("electron");
electron.contextBridge.exposeInMainWorld("ipcRenderer", {
  on(...args) {
    const [channel, listener] = args;
    return electron.ipcRenderer.on(channel, (event, ...args2) => listener(event, ...args2));
  },
  off(...args) {
    const [channel, ...omit] = args;
    return electron.ipcRenderer.off(channel, ...omit);
  },
  send(...args) {
    const [channel, ...omit] = args;
    return electron.ipcRenderer.send(channel, ...omit);
  },
  invoke(...args) {
    const [channel, ...omit] = args;
    return electron.ipcRenderer.invoke(channel, ...omit);
  }
  // You can expose other APTs you need here.
  // ...
});
electron.contextBridge.exposeInMainWorld("api", {
  gastos: {
    getAll: () => electron.ipcRenderer.invoke("gastos:getAll"),
    getById: (id) => electron.ipcRenderer.invoke("gastos:getById", id),
    create: (gasto) => electron.ipcRenderer.invoke("gastos:create", gasto),
    delete: (id) => electron.ipcRenderer.invoke("gastos:delete", id)
  }
});
